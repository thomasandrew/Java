package model.dao;

import model.Aluno;
import model.Curso;
import model.Aluno;

public class DaoAluno {
	//
	// CONSTANTES
	//
	final public static int FATOR_CRESCIMENTO = 3;
	final public static int TAMANHO_INICIAL   = 2;
	
	//
	// ATRIBUTOS
	//
	private static Aluno[] conjAlunos = new Aluno[TAMANHO_INICIAL];
	private static int     numObjetos = 0;
	
	//
	// MÉTODOS
	//
	public DaoAluno() {
		super();
	}
	
	/**
	 * Adiciona um objeto Aluno ao conjunto de objetos gerenciados pelo DAO
	 * @param novo
	 * @return
	 */
	public boolean adicionar(Aluno novo) {
		int tamanho = DaoAluno.conjAlunos.length;
		// Se o array 'conjAlunos' já está todo preenchido, então o 'numObjetos'
		// está igual a 'conjAlunos.length'. Se for verdadeiro, vamos criar um 
		// novoArray maior para este Dao.
		if(DaoAluno.numObjetos == tamanho) {
			// Criando um array maior
			Aluno[] novoArray = new Aluno[ tamanho + FATOR_CRESCIMENTO ];
			// Copiando as referências dos objetos presentes 
			// em conjAlunos para o novoArray
			for(int i = 0; i < tamanho; i++)
				novoArray[i] = DaoAluno.conjAlunos[i];
			// Vamos descartar o 'conjAlunos' antigo e indicar que o novoArray
			// agora é o novo 'conjAlunos'
			DaoAluno.conjAlunos = novoArray;
		}
		DaoAluno.conjAlunos[DaoAluno.numObjetos] = novo;
		DaoAluno.numObjetos++;
		return true;
	}

	/**
	 * Retorna o Aluno presente na posição indicada por parâmetro
	 * @param posicao
	 * @return
	 */
	public Aluno obter(int posicao) {
		// Se a posição não for válida, retornamos null
		if(posicao < 0 || posicao >= DaoAluno.numObjetos)
			return null;
		return DaoAluno.conjAlunos[posicao];
	}
	
	/**
	 * Retorna o número de objetos Aluno gerenciados pelo Dao
	 * @return
	 */
	public int getNumObjetos() {
		return DaoAluno.numObjetos;
	}
	
	/**
	 * Retorna uma cópia do array de ponteiros para Aluno gerenciado pelo DAO
	 * @return
	 */
	public Aluno[] obterAlunos() {
		Aluno[] copia = new Aluno[DaoAluno.numObjetos];
		for(int i = 0; i < DaoAluno.numObjetos; i++)
			copia[i] = DaoAluno.conjAlunos[i];
		return copia;
	}

	/**
	 * Adiciona todos os objetos presentes no array passado por parâmetro no DAO
	 * @param conj
	 */
	public void adicionarTodos(Aluno[] conj) {
		if(conj == null)
			return;
		for(int i = 0; i < conj.length; i++) {
			Aluno obj = conj[i];
			if(obj != null)
				this.adicionar(obj);
		}
	}
}
