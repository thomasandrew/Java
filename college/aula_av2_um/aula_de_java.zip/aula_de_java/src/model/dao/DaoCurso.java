package model.dao;

import model.Aluno;
import model.Curso;

public class DaoCurso {
	//
	// CONSTANTES
	//
	final public static int FATOR_CRESCIMENTO = 3;
	final public static int TAMANHO_INICIAL   = 2;
	
	//
	// ATRIBUTOS
	//
	private static Curso[] conjCursos = new Curso[TAMANHO_INICIAL];
	private static int     numObjetos = 0;
	
	//
	// MÉTODOS
	//
	public DaoCurso() {
		super();
	}
	
	/**
	 * Adiciona um objeto Curso ao conjunto de objetos gerenciados pelo DAO
	 * @param novo
	 * @return
	 */
	public boolean adicionar(Curso novo) {
		int tamanho = DaoCurso.conjCursos.length;
		// Se o array 'conjCursos' já está todo preenchido, então o 'numObjetos'
		// está igual a 'conjCursos.length'. Se for verdadeiro, vamos criar um 
		// novoArray maior para este Dao.
		if(DaoCurso.numObjetos == tamanho) {
			// Criando um array maior
			Curso[] novoArray = new Curso[ tamanho + FATOR_CRESCIMENTO ];
			// Copiando as referências dos objetos presentes 
			// em conjCursos para o novoArray
			for(int i = 0; i < tamanho; i++)
				novoArray[i] = DaoCurso.conjCursos[i];
			// Vamos descartar o 'conjCursos' antigo e indicar que o novoArray
			// agora é o novo 'conjCursos'
			DaoCurso.conjCursos = novoArray;
		}
		DaoCurso.conjCursos[DaoCurso.numObjetos] = novo;
		DaoCurso.numObjetos++;
		return true;
	}

	/**
	 * Retorna a Curso presente na posição indicada por parâmetro
	 * @param posicao
	 * @return
	 */
	public Curso obter(int posicao) {
		// Se a posição não for válida, retornamos null
		if(posicao < 0 || posicao >= DaoCurso.numObjetos)
			return null;
		return DaoCurso.conjCursos[posicao];
	}
	
	/**
	 * Retorna o número de objetos Curso gerenciados pelo Dao
	 * @return
	 */
	public int getNumObjetos() {
		return DaoCurso.numObjetos;
	}
	
	/**
	 * Retorna uma cópia do array de ponteiros para Curso gerenciado pelo DAO
	 * @return
	 */
	public Curso[] obterCursos() {
		Curso[] copia = new Curso[DaoCurso.numObjetos];
		for(int i = 0; i < DaoCurso.numObjetos; i++)
			copia[i] = DaoCurso.conjCursos[i];
		return copia;
	}

	/**
	 * Adiciona todos os objetos presentes no array passado por parâmetro no DAO
	 * @param conj
	 */
	public void adicionarTodos(Curso[] conj) {
		if(conj == null)
			return;
		for(int i = 0; i < conj.length; i++) {
			Curso obj = conj[i];
			if(obj != null)
				this.adicionar(obj);
		}
	}
}
