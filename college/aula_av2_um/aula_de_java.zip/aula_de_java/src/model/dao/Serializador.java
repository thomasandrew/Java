package model.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import model.Aluno;
import model.Curso;
import model.Pessoa;

public class Serializador {

	public static void salvarObjetos() {
		try {
			FileOutputStream fos = new FileOutputStream("objetos.data");
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			//
			// Não esqueça de colocar nas classes 'model' o 'implements Serializable' na 
			// declaração da classe e o 'private static final long serialVersionUID = 1L;'
			//
			Curso[] listaCursos = new DaoCurso().obterCursos();
			oos.writeObject(listaCursos);

			Pessoa[] listaPessoas = new DaoPessoa().obterPessoas();
			oos.writeObject(listaPessoas);

			Aluno[] listaAlunos = new DaoAluno().obterAlunos();
			oos.writeObject(listaAlunos);

			oos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void recuperarObjetos() {
		try {
			FileInputStream fis = new FileInputStream("objetos.data");
			ObjectInputStream ois = new ObjectInputStream(fis);

			// A ordem de leitura precisa ser a mesma de escrita
			// empregada no método acima
			Curso[] listaCursos = (Curso[]) ois.readObject();
			Pessoa[] listaPessoas = (Pessoa[]) ois.readObject();
			Aluno[] listaAlunos = (Aluno[]) ois.readObject();

			new DaoCurso().adicionarTodos(listaCursos);
			new DaoPessoa().adicionarTodos(listaPessoas);
			new DaoAluno().adicionarTodos(listaAlunos);

			ois.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
