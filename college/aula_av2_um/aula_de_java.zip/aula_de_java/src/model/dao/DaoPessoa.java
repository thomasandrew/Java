package model.dao;

import model.Curso;
import model.Pessoa;
import model.Pessoa;

public class DaoPessoa {
	//
	// CONSTANTES
	//
	final public static int FATOR_CRESCIMENTO = 3;
	final public static int TAMANHO_INICIAL = 2;

	//
	// ATRIBUTOS
	//
	private static Pessoa[] conjPessoas = new Pessoa[TAMANHO_INICIAL];
	private static int numObjetos = 0;

	//
	// MÉTODOS
	//
	public DaoPessoa() {
		super();
	}

	/**
	 * Adiciona um objeto Pessoa ao conjunto de objetos gerenciados pelo DAO
	 * 
	 * @param novo
	 * @return
	 */
	public boolean adicionar(Pessoa novo) {
		int tamanho = DaoPessoa.conjPessoas.length;
		// Se o array 'conjPessoas' já está todo preenchido, então o 'numObjetos'
		// está igual a 'conjPessoas.length'. Se for verdadeiro, vamos criar um
		// novoArray maior para este Dao.
		if (DaoPessoa.numObjetos == tamanho) {
			// Criando um array maior
			Pessoa[] novoArray = new Pessoa[tamanho + FATOR_CRESCIMENTO];
			// Copiando as referências dos objetos presentes
			// em conjPessoas para o novoArray
			for (int i = 0; i < tamanho; i++)
				novoArray[i] = DaoPessoa.conjPessoas[i];
			// Vamos descartar o 'conjPessoas' antigo e indicar que o novoArray
			// agora é o novo 'conjPessoas'
			DaoPessoa.conjPessoas = novoArray;
		}
		DaoPessoa.conjPessoas[DaoPessoa.numObjetos] = novo;
		DaoPessoa.numObjetos++;
		return true;
	}

	/**
	 * Retorna a Pessoa presente na posição indicada por parâmetro
	 * 
	 * @param posicao
	 * @return
	 */
	public Pessoa obter(int posicao) {
		// Se a posição não for válida, retornamos null
		if (posicao < 0 || posicao >= DaoPessoa.numObjetos)
			return null;
		return DaoPessoa.conjPessoas[posicao];
	}

	/**
	 * Retorna o número de objetos Pessoa gerenciados pelo Dao
	 * 
	 * @return
	 */
	public int getNumObjetos() {
		return DaoPessoa.numObjetos;
	}

	/**
	 * Retorna uma cópia do array de ponteiros para Pessoa gerenciado pelo DAO
	 * 
	 * @return
	 */
	public Pessoa[] obterPessoas() {
		Pessoa[] copia = new Pessoa[DaoPessoa.numObjetos];
		for (int i = 0; i < DaoPessoa.numObjetos; i++)
			copia[i] = DaoPessoa.conjPessoas[i];
		return copia;
	}

	/**
	 * Adiciona todos os objetos presentes no array passado por parâmetro no DAO
	 * 
	 * @param conj
	 */
	public void adicionarTodos(Pessoa[] conj) {
		if (conj == null)
			return;
		for (int i = 0; i < conj.length; i++) {
			Pessoa obj = conj[i];
			if (obj != null)
				this.adicionar(obj);
		}
	}
}
