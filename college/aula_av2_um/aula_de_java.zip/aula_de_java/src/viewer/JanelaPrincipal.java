package viewer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.CtrlPrograma;
import model.Aluno;
import model.Pessoa;
import model.dao.DaoAluno;
import model.dao.DaoPessoa;
import model.dao.Serializador;

public class JanelaPrincipal extends JFrame {
	
	//
	// ATRIBUTOS
	//

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private CtrlPrograma ctrl;

	/**
	 * Create the frame.
	 * @param ctrl 
	 */
	public JanelaPrincipal(CtrlPrograma ctrl) {
		this.ctrl = ctrl;
		setTitle("Janela Principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 486, 120);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btPessoas = new JButton("Pessoas");
		btPessoas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new JanelaConsultarPessoas();
			}
		});
		btPessoas.setBounds(10, 11, 89, 63);
		contentPane.add(btPessoas);
		
		JButton btSair = new JButton("Sair");
		btSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Enviamos para o controlador do programa a mensagem encerrar programa 
				// solicitamos o controlador tome as medidas necessarias 
				// para o encerramento do programa
				ctrl.encerrarPrograma();
			}
		});
		btSair.setBounds(360, 11, 89, 63);
		contentPane.add(btSair);
		
		JButton btAlunos = new JButton("Alunos");
		btAlunos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ctrl.iniciarCasoDeUsoConsultarCurso();
			}
		});
		btAlunos.setBounds(129, 11, 89, 63);
		contentPane.add(btAlunos);
		
		JButton btCursos = new JButton("Cursos");
		btCursos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Envio para o CrtlPrograma a mensagem indicandp
				// que o usuario que inicuar a execusao de caso de uso
				// consultar curso
				ctrl.iniciarCasoDeUsoConsultarCurso();
			}
		});
		btCursos.setBounds(246, 11, 89, 63);
		contentPane.add(btCursos);
		
		// Torno a Janela Principal Visível
		this.setVisible(true);
	}
}
