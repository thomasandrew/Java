package controller;

import viewer.JanelaCurso;

public class CtrlIncluirCurso {
	private CtrlConsultarCursos ctrlPai;
	private JanelaCurso janela;
	
	public CtrlIncluirCurso(CtrlConsultarCursos ctrlPai) {
		this.ctrlPai = ctrlPai;
		this.janela = new JanelaCurso(this);
	}
}
