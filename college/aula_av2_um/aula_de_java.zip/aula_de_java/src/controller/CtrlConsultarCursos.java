package controller;

import viewer.JanelaConsultarCursos;

public class CtrlConsultarCursos {
	//
	// ATRIBUTOS
	//
	private CtrlPrograma ctrlPai;
	private CtrlIncluirCurso ctrlIncluirCurso;
	private JanelaConsultarCursos janelaConsulta;
	
	//
	// MÉTODOS
	//
	public CtrlConsultarCursos(CtrlPrograma ctrlPai) {
		this.ctrlPai = ctrlPai;
		this.janelaConsulta = new JanelaConsultarCursos(this);
	}
	
	public void iniciarCasoDeUsoIncluirCurso() {
		this.ctrlIncluirCurso = new CtrlIncluirCurso(this);
	}
}
