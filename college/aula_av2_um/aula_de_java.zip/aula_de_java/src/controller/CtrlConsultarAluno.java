package controller;

import viewer.JanelaConsultarAlunos;

public class CtrlConsultarAluno {
	private CtrlPrograma ctrlPai;
	private JanelaConsultarAlunos janelaConsultarAlunos;
	
	public CtrlConsultarAluno(CtrlPrograma ctrlPai) {
		this.ctrlPai = ctrlPai;
		this.janelaConsultarAlunos = new JanelaConsultarAlunos(this);
	}
}
