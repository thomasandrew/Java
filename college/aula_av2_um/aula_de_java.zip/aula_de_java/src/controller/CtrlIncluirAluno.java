package controller;

import viewer.JanelaAluno;

public class CtrlIncluirAluno {
	private CtrlConsultarAluno ctrlPai;
	private JanelaAluno janela;
	
	public CtrlIncluirAluno(CtrlConsultarAluno ctrlPai) {
		this.ctrlPai = ctrlPai;
		this.janela = new JanelaAluno(this);
	}
}
